
function validacaoUsuario() {
    if (!($('#usuario')[0].checkValidity())) {
        // Seta o campo, seu pai e seus irmãos de vermelho, informando o erro na validação
        $('#usuario').parent().addClass("has-error");
        $('#usuario').siblings().addClass("erro");
        $('#usuario').siblings('.error-message')[0].innerHTML = $('#usuario')[0].validationMessage;
    } else {
        // Seta o campo, seu pai e seus irmãos para as configurações padrões
        $('#usuario').parent().removeClass("has-error");
        $('#usuario').siblings().removeClass("erro");
        $('#usuario').siblings('.error-message').removeClass("has-error");
        $('#usuario').siblings('.error-message')[0].innerHTML = "";
    }
};

function validacaoSenha() {
    if (!($('#senha')[0].checkValidity())) {
        // Seta o campo, seu pai e seus irmãos de vermelho, informando o erro na validação
        $('#senha').parent().addClass("has-error");
        $('#senha').siblings().addClass("erro");
        $('#senha').siblings('.error-message').addClass("has-error");
        $('#senha').siblings('.error-message')[0].innerHTML = $('#senha')[0].validationMessage;
    } else {
        // Seta o campo, seu pai e seus irmãos para as configurações padrões
        $('#senha').parent().removeClass("has-error");
        $('#senha').siblings().removeClass("erro");
        $('#senha').siblings('.error-message').removeClass("has-error");
        $('#senha').siblings('.error-message')[0].innerHTML = "";
    }
};

function exibeAlerta() {
    // Exibe o alerta
    $('#alerta').show();

    // Fecha o alerta depois de 3 segundos
    setTimeout(function () { $('#alerta').hide() }, 3000);
};

$('#usuario').on({
    blur: validacaoUsuario,
    keyup: validacaoUsuario,
    submit: validacaoUsuario
});

$('#senha').on({
    blur: validacaoSenha,
    keyup: validacaoSenha,
    submit: validacaoSenha
});

$('#entrar').on({
    click: function (event) {
        event.preventDefault(); // impede que o evento padrão ocorra (ex.: seguir um link);

        if ((!($('#usuario')[0].checkValidity())) || (!($('#senha')[0].checkValidity()))) {
            exibeAlerta
        }
        else {
            // AJAX

            $.ajax({
                url: "http://ldxscriptsdev.fw.landix.com.br/landix/login/",
                type: "post",
                data: {
                    username: $('#usuario').val(),
                    password: $('#senha').val()
                }
            })
                .done(
                    function(data) {
                        localStorage.setItem("dados", JSON.stringify(data))
                        window.location.href = 'pages/home.html'
                    }
                )
                .fail(
                    function(data) {
                        $('#alerta').html(JSON.parse(data.responseText).detail)
                        exibeAlerta()
                    }
                )
        }
    }
});

// jq

// put/post: se id === 'string'
// contentType:'application/json'